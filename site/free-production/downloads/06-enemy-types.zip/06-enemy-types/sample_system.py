"""[SYSTEM] この改造例だけの描画。hp・score・座標は変更しない。"""


from pathlib import Path


import pygame


def load_sprite(folder, name, size):
    try:
        image = pygame.image.load(str(Path(folder) / "images" / name)).convert_alpha()
        return pygame.transform.scale(image, (size, size))
    except (OSError, pygame.error):
        return None


def draw_actor(screen, image, label, x, y, size, color):
    if image is not None:
        screen.blit(image, (x, y))
    else:
        pygame.draw.rect(screen, color, (x, y, size, size))
    screen.blit(label, label.get_rect(midbottom=(x + size // 2, y - 4)))
