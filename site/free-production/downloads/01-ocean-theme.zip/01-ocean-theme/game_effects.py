"""POLISHEDの表示・音・被弾保護SYSTEM。学習用のHP更新はmain flowに残す。"""

import math
import os
import random

import pygame


def load_image(folder, filename, size):
    try:
        source = pygame.image.load(os.path.join(folder, "images", filename)).convert_alpha()
        return pygame.transform.scale(source, size)
    except (pygame.error, OSError):
        return None


def load_sound(folder, filename, volume):
    if pygame.mixer.get_init() is not None:
        try:
            sound = pygame.mixer.Sound(os.path.join(folder, "sounds", filename))
            sound.set_volume(volume)
            return sound
        except (pygame.error, OSError):
            pass
    return None


def play_sound(sound):
    if sound is not None:
        try:
            sound.stop()  # 同じSEの重なりを避け、短い音を明瞭に保ちます。
            sound.play()
        except pygame.error:
            return None
    return sound


def create_presentation(folder, width, height, player_size, enemy_size, bullet_width, bullet_height):
    # ゲームのrandom.randintとは別の乱数器。演出で敵の再配置を変えません。
    rng = random.Random(20261017)
    stars = []
    for index in range(24):
        layer = index % 3
        stars.append({"x": rng.randrange(width), "y": rng.randrange(height),
                      "speed": (0.45, 0.85, 1.35)[layer], "size": 1 if layer < 2 else 2})
    images = {"background": load_image(folder, "background.png", (width, height)),
              "player": load_image(folder, "player.png", (player_size, player_size)),
              "enemy": load_image(folder, "enemy.png", (enemy_size, enemy_size)),
              "bullet": load_image(folder, "bullet.png", (bullet_width, bullet_height))}
    # 欠損時も識別できる簡素な形。最終画像と当たり判定の大きさは共通です。
    player = pygame.Surface((32, 32), pygame.SRCALPHA)
    pygame.draw.polygon(player, (76, 211, 245), ((16, 0), (31, 30), (16, 24), (0, 30)))
    pygame.draw.polygon(player, (235, 252, 255), ((16, 6), (21, 19), (11, 19)))
    enemy = pygame.Surface((32, 32), pygame.SRCALPHA)
    pygame.draw.polygon(enemy, (255, 167, 83), ((8, 0), (24, 1), (31, 12), (25, 30), (8, 31), (0, 17)))
    pygame.draw.circle(enemy, (155, 69, 51), (10, 11), 4)
    bullet = pygame.Surface((bullet_width, bullet_height), pygame.SRCALPHA)
    pygame.draw.rect(bullet, (225, 252, 255), bullet.get_rect(), border_radius=3)
    fallback = {"player": pygame.transform.scale(player, (player_size, player_size)),
                "enemy": pygame.transform.scale(enemy, (enemy_size, enemy_size)), "bullet": bullet}
    damage_overlay = pygame.Surface((width, height), pygame.SRCALPHA)
    damage_overlay.fill((232, 60, 80, 255))
    heart = pygame.Surface((26, 24), pygame.SRCALPHA)
    pygame.draw.polygon(heart, (255, 129, 149),
                        ((2, 3), (8, 1), (13, 6), (18, 1), (24, 3), (26, 9), (13, 23), (0, 9)))
    empty_heart = pygame.Surface((26, 24), pygame.SRCALPHA)
    pygame.draw.polygon(empty_heart, (111, 133, 159),
                        ((2, 3), (8, 1), (13, 6), (18, 1), (24, 3), (26, 9), (13, 23), (0, 9)), 2)
    shade = pygame.Surface((width, height), pygame.SRCALPHA)
    shade.fill((4, 9, 22, 175))
    meta_font = pygame.font.Font(None, 23)
    score_font = pygame.font.Font(None, 42)
    title_font = pygame.font.Font(None, 74)
    message_font = pygame.font.Font(None, 30)
    data = {"width": width, "height": height, "rng": rng, "stars": stars,
            "images": images, "fallback": fallback, "heart": heart, "empty_heart": empty_heart,
            "damage_overlay": damage_overlay, "shade": shade, "sparks": [], "hit_start": -1000,
            "invincible_until": 0, "player_visible": True,
            "damage_start": -1000, "score": None, "hp": None, "score_font": score_font,
            "score_label": meta_font.render("SCORE", True, (137, 163, 193)),
            "life_label": meta_font.render("HP", True, (137, 163, 193)),
            "title": title_font.render("GAME OVER", True, (233, 242, 255)),
            "restart": message_font.render("Press R to Restart", True, (111, 225, 247)),
            "hud_score_origin": (24, 17), "hud_life_origin": (width - 126, 17),
            "final_score_font": message_font, "final_score": None, "music_ready": False,
            "music_paused": False, "effects_enabled": True,
            "shoot_sound": None, "hit_sound": None, "damage_sound": None}
    if pygame.mixer.get_init() is None:
        try:
            pygame.mixer.init()
        except pygame.error:
            pass
    data["shoot_sound"] = load_sound(folder, "shoot.wav", 0.55)
    data["hit_sound"] = load_sound(folder, "hit.wav", 0.65)
    data["damage_sound"] = load_sound(folder, "damage.wav", 0.55)
    if pygame.mixer.get_init() is not None:
        try:
            pygame.mixer.music.load(os.path.join(folder, "sounds", "bgm.wav"))
            pygame.mixer.music.set_volume(0.18)
            pygame.mixer.music.play(-1)
            data["music_ready"] = True
        except (pygame.error, OSError):
            pass
    return data


def reset_presentation(data):
    data["sparks"].clear()
    data["hit_start"] = -1000
    data["damage_start"] = -1000
    data["invincible_until"] = 0
    data["player_visible"] = True
    data["rng"].seed(20261017)
    for star in data["stars"]:
        star["x"] = data["rng"].randrange(data["width"])
        star["y"] = data["rng"].randrange(data["height"])
    data["music_paused"] = False
    try:
        pygame.mixer.stop()
        if data["music_ready"]:
            pygame.mixer.music.stop()
            pygame.mixer.music.play(-1)
    except pygame.error:
        data["music_ready"] = False


def can_take_damage(data):
    # 時刻の管理だけ。接触条件・HP減少・終了条件は生徒コードに残します。
    return pygame.time.get_ticks() >= data["invincible_until"]


def update_presentation(data, fired, hit, damage, hit_center, game_over, restarted):
    now = pygame.time.get_ticks()
    if not game_over and not restarted:
        for star in data["stars"]:
            star["y"] = star["y"] + star["speed"]
            if star["y"] > data["height"]:
                star["y"] = -star["size"]
                star["x"] = data["rng"].randrange(data["width"])
    if fired:
        data["shoot_sound"] = play_sound(data["shoot_sound"])
    if hit:
        data["hit_start"] = now
        data["sparks"].clear()
        for index in range(8):
            angle = index * math.tau / 8 + data["rng"].uniform(-0.12, 0.12)
            data["sparks"].append({"x": hit_center[0], "y": hit_center[1],
                                   "vx": math.cos(angle) * 190, "vy": math.sin(angle) * 190})
        data["hit_sound"] = play_sound(data["hit_sound"])
    if damage:
        data["damage_sound"] = play_sound(data["damage_sound"])
        if not game_over and not restarted:
            data["damage_start"] = now
            data["invincible_until"] = now + 800
    if game_over or restarted:
        # 致死時は終了表示を優先し、無敵・点滅・赤フェードを残しません。
        data["invincible_until"] = 0
        data["damage_start"] = -1000
        data["player_visible"] = True
    else:
        data["player_visible"] = (now >= data["invincible_until"] or
                                  (now - data["damage_start"]) // 100 % 2 == 0)
    if now - data["hit_start"] >= 240:
        data["sparks"].clear()
    if game_over and data["music_ready"] and not data["music_paused"]:
        try:
            pygame.mixer.music.pause()
            data["music_paused"] = True
        except pygame.error:
            data["music_ready"] = False


def draw_feedback(data, screen, player_x, player_y):
    # この演出の描画が失敗しても、ゲームルールと通常表示は続けます。
    now = pygame.time.get_ticks()
    age = (now - data["hit_start"]) / 1000
    if 0 <= age < 0.24:
        for spark in data["sparks"]:
            head = (int(spark["x"] + spark["vx"] * age), int(spark["y"] + spark["vy"] * age))
            tail_age = max(0, age - 0.04)
            tail = (int(spark["x"] + spark["vx"] * tail_age), int(spark["y"] + spark["vy"] * tail_age))
            color = (255, int(215 - 80 * age / 0.24), 110)
            pygame.draw.line(screen, color, tail, head, 2)
            pygame.draw.circle(screen, (255, 246, 219), head, 1)
    damage_age = now - data["damage_start"]
    if 0 <= damage_age < 200:
        data["damage_overlay"].set_alpha(int(42 * (1 - damage_age / 200)))
        screen.blit(data["damage_overlay"], (0, 0))


def draw_scene(data, screen, player_x, player_y, enemy_x, enemy_y,
               bullet_x, bullet_y, bullet_active, score, hp, game_over):
    screen.fill((8, 15, 31))
    if data["images"]["background"] is not None:
        screen.blit(data["images"]["background"], (0, 0))
    for star in data["stars"]:
        color = (54, 78, 108) if star["size"] == 1 else (96, 133, 163)
        pygame.draw.rect(screen, color, (int(star["x"]), int(star["y"]), star["size"], star["size"] * 2))
    for name, position in (("enemy", (enemy_x, enemy_y)), ("player", (player_x, player_y))):
        if name == "player" and not data["player_visible"]:
            continue
        image = data["images"][name]
        screen.blit(image if image is not None else data["fallback"][name], position)
    if bullet_active == True:
        image = data["images"]["bullet"]
        screen.blit(image if image is not None else data["fallback"]["bullet"], (bullet_x, bullet_y))
    if data["effects_enabled"]:
        try:
            draw_feedback(data, screen, player_x, player_y)
        except pygame.error:
            data["effects_enabled"] = False
            data["sparks"].clear()
    if game_over:
        screen.blit(data["shade"], (0, 0))
    if data["score"] != score:
        data["score"] = score
        data["score_text"] = data["score_font"].render(str(score).zfill(6), True, (233, 242, 255))
        data["final_score"] = data["final_score_font"].render("Final Score  " + str(score), True, (192, 210, 233))
    data["hp"] = hp
    if game_over:
        screen.blit(data["title"], data["title"].get_rect(center=(data["width"] // 2, data["height"] // 2 - 38)))
        screen.blit(data["final_score"], data["final_score"].get_rect(center=(data["width"] // 2, data["height"] // 2 + 16)))
        screen.blit(data["restart"], data["restart"].get_rect(center=(data["width"] // 2, data["height"] // 2 + 68)))
    # HUDは固定位置。対象・演出・Game Over表示の後、常に最前面へ描きます。
    score_origin = data["hud_score_origin"]
    life_origin = data["hud_life_origin"]
    screen.blit(data["score_label"], score_origin)
    screen.blit(data["score_text"], (score_origin[0], score_origin[1] + 18))
    screen.blit(data["life_label"], life_origin)
    for index in range(3):
        icon = data["heart"] if index < hp else data["empty_heart"]
        screen.blit(icon, (life_origin[0] + index * 34, life_origin[1] + 21))


def close_presentation(data):
    try:
        pygame.mixer.music.stop()
        pygame.mixer.stop()
    except pygame.error:
        pass
