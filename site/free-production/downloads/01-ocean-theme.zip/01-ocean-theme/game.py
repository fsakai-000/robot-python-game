import os
import random

import pygame
from game_effects import (create_presentation, reset_presentation,
                              update_presentation, draw_scene, close_presentation,
                              can_take_damage)


# ========================================
# [READ] Game2 MASTERの設定
# ========================================
screen_width = 800
screen_height = 600
fps = 60

player_speed = 5
enemy_speed = 4
bullet_speed = 10
player_size = 64
enemy_size = 64
bullet_width = 8
bullet_height = 16

background_color = (10, 19, 38)
player_color = (76, 211, 245)
enemy_color = (255, 167, 83)
bullet_color = (255, 244, 216)
text_color = (233, 242, 255)


# ========================================
# [SYSTEM] 画面の準備
# 今は変更しなくてOK
# ========================================
pygame.display.init()
pygame.font.init()
try:
    screen = pygame.display.set_mode(
        (screen_width, screen_height), pygame.SCALED, vsync=1
    )
except (pygame.error, TypeError):
    screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
font = pygame.font.Font(None, 36)
game_over_font = pygame.font.Font(None, 72)
game_folder = os.path.dirname(os.path.abspath(__file__))
asset_folder = os.path.join(game_folder, "assets")
if not os.path.isdir(asset_folder):
    asset_folder = os.path.abspath(os.path.join(game_folder, "..", "assets"))

pygame.display.set_caption("SAMPLE 01 | OCEAN")
presentation = create_presentation(asset_folder, screen_width, screen_height,
                                   player_size, enemy_size, bullet_width, bullet_height)

# ========================================
# [READ] ゲーム開始時の状態
# ========================================
player_x = screen_width // 2 - player_size // 2
player_y = screen_height - player_size - 30
enemy_x = random.randint(0, screen_width - enemy_size)
enemy_y = -enemy_size
bullet_x = player_x + player_size // 2 - bullet_width // 2
bullet_y = player_y - bullet_height
bullet_active = False
score = 0
hp = 3
game_over = False
running = True

displayed_score = score
displayed_hp = hp
score_text = font.render("Score: " + str(score), True, text_color)
hp_text = font.render("HP: " + str(hp), True, text_color)


# ========================================
# [SYSTEM] 入力とゲームループ
# 今は変更しなくてOK
# ========================================
while running:
    fire_requested = False
    shot_fired = False
    enemy_contact = False
    enemy_hit = False
    restarted = False

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

            if event.key == pygame.K_r and game_over:
                player_x = screen_width // 2 - player_size // 2
                player_y = screen_height - player_size - 30
                enemy_x = random.randint(0, screen_width - enemy_size)
                enemy_y = -enemy_size
                bullet_x = player_x + player_size // 2 - bullet_width // 2
                bullet_y = player_y - bullet_height
                bullet_active = False
                score = 0
                hp = 3
                game_over = False
                fire_requested = False
                restarted = True
                reset_presentation(presentation)

            # 飛行中・Game Over中・再開直後の入力は予約しません。
            if event.key == pygame.K_SPACE and not getattr(event, "repeat", False):
                if not game_over and not bullet_active and not restarted:
                    fire_requested = True

    if not running:
        break

    if not game_over and not restarted:
        # [READ] 押されているキーを調べます。
        keys = pygame.key.get_pressed()

        # ========================================
        # [LEARNED] Student Edit Zone：4方向移動・画面外制限
        # ========================================
        if keys[pygame.K_RIGHT]:
            player_x = player_x + player_speed

        if keys[pygame.K_LEFT]:
            player_x = player_x - player_speed

        if keys[pygame.K_DOWN]:
            player_y = player_y + player_speed

        if keys[pygame.K_UP]:
            player_y = player_y - player_speed

        if player_x < 0:
            player_x = 0

        if player_x > screen_width - player_size:
            player_x = screen_width - player_size

        if player_y < 0:
            player_y = 0

        if player_y > screen_height - player_size:
            player_y = screen_height - player_size
        # ========================================

        # ========================================
        # [READ] 敵を下へ動かし、画面の下から上へ戻す
        # ========================================
        enemy_y = enemy_y + enemy_speed
        if enemy_y > screen_height:
            enemy_y = -enemy_size
            enemy_x = random.randint(0, screen_width - enemy_size)
        # ========================================

        # [SYSTEM] 新しい発射要求がある時だけ、発射します。
        if fire_requested:
            # [READ] プレイヤーの中央の真上から出します。
            bullet_x = player_x + player_size // 2 - bullet_width // 2
            bullet_y = player_y - bullet_height

            # ========================================
            # [LEARNED] Student Edit Zone：弾を出す
            # ========================================
            bullet_active = True
            # ========================================
            # [SYSTEM] 発射したことを音へ伝えます。
            shot_fired = True

        # [READ] 弾が出ている間だけ更新します。
        if bullet_active == True:
            # ========================================
            # [LEARNED] Student Edit Zone：上移動・画面外で弾を消す
            # ========================================
            bullet_y = bullet_y - bullet_speed
            if bullet_y + bullet_height < 0:
                bullet_active = False
            # ========================================

        # ========================================
        # [READ] 当たり判定に使う四角
        # ========================================
        player_rect = pygame.Rect(player_x, player_y, player_size, player_size)
        enemy_rect = pygame.Rect(enemy_x, enemy_y, enemy_size, enemy_size)
        bullet_rect = pygame.Rect(bullet_x, bullet_y, bullet_width, bullet_height)

        # [SYSTEM] 被弾後800msは接触damageを調べません。
        if can_take_damage(presentation):
            # ========================================
            # [LEARNED] Student Edit Zone：接触・HP・終了条件
            # ========================================
            if player_rect.colliderect(enemy_rect):
                hp = hp - 1
                if hp <= 0:
                    game_over = True

                # [SYSTEM] Zoneここまで。同じ接触を次のframeへ残しません。
                enemy_y = -enemy_size
                enemy_x = random.randint(0, screen_width - enemy_size)
                enemy_contact = True
            # ========================================

        # [SYSTEM] 接触を優先し、同じ敵への二重結果を防ぎます。
        if bullet_active and not enemy_contact and not game_over:
            # ========================================
            # [LEARNED] Student Edit Zone：弾の判定・得点・敵の再配置
            # ========================================
            if bullet_rect.colliderect(enemy_rect):
                score = score + 100
                enemy_y = -enemy_size
                enemy_x = random.randint(0, screen_width - enemy_size)

                # [READ] Zoneここまで。命中した弾は1回で消費します。
                bullet_active = False
                # [SYSTEM] 撃破したことを音へ伝えます。
                enemy_hit = True
            # ========================================

    # ========================================
    # [SYSTEM] POLISHEDの背景・演出・音・描画
    # ゲームの座標・score・hpを書き換えません。
    # ========================================
    update_presentation(presentation, shot_fired, enemy_hit, enemy_contact,
                        enemy_rect.center if enemy_hit else (0, 0),
                        game_over, restarted)
    if score != displayed_score:
        score_text = font.render("Score: " + str(score), True, text_color)
        displayed_score = score
    if hp != displayed_hp:
        hp_text = font.render("HP: " + str(hp), True, text_color)
        displayed_hp = hp
    draw_scene(presentation, screen, player_x, player_y, enemy_x, enemy_y,
               bullet_x, bullet_y, bullet_active, score, hp, game_over)
    pygame.display.flip()
    clock.tick_busy_loop(fps)

close_presentation(presentation)
pygame.quit()

