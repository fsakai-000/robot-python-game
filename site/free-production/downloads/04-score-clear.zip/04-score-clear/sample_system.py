"""[SYSTEM] この改造例だけの描画。hp・score・座標は変更しない。"""


from pathlib import Path


import pygame


def create_clear_visual():
    shade = pygame.Surface((800, 270), pygame.SRCALPHA)
    shade.fill((7, 20, 37, 230))
    title = pygame.font.Font(None, 88).render("CLEAR", True, (117, 244, 196))
    restart = pygame.font.Font(None, 32).render("500 POINTS  /  Press R to Restart", True, (233, 242, 255))
    return shade, title, restart


def draw_clear(screen, visual):
    shade, title, restart = visual
    screen.blit(shade, (0, 165))
    screen.blit(title, title.get_rect(center=(400, 280)))
    screen.blit(restart, restart.get_rect(center=(400, 345)))
