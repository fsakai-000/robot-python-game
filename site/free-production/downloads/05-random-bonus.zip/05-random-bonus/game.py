import os
import random

import pygame

# ========================================
# 今日の学習
# ========================================
#
# 今日はコードを探して改造する回です。
# Level A 設定値を変える
# Level B ルールを変える
# Level C 画像を差し替える
# Level D 自作ドット絵に挑戦する
#
# 改造したい内容に近いコードを自分で探します。
# ========================================

# ========================================
# [LEARNED] ゲームの設定
# ========================================
# ゲームの設定値です。数字を変えると、ゲームの見た目や難しさが変わります。
screen_width = 800
screen_height = 600
fps = 60

player_speed = 5
enemy_speed = 4

player_size = 64
enemy_size = 64
item_size = 64

background_color = (225, 240, 255)
player_color = (50, 120, 240)
enemy_color = (230, 70, 70)
item_color = (255, 190, 40)
text_color = (30, 40, 55)

# ゲームを動かすための処理
# ========================================
# [SYSTEM] Pygameと画面の準備
# ここは変更しません。
# ========================================
pygame.init()

# VSyncを使える環境では利用し、対応していない環境では通常表示に戻します。
try:
    screen = pygame.display.set_mode(
        (screen_width, screen_height), pygame.SCALED, vsync=1
    )
except (pygame.error, TypeError):
    screen = pygame.display.set_mode((screen_width, screen_height))

pygame.display.set_caption("DODGE & COLLECT")
clock = pygame.time.Clock()

font = pygame.font.Font(None, 36)
game_over_font = pygame.font.Font(None, 72)

# ゲームの演出
# ========================================
# [SYSTEM] 画像・音・演出の準備
# ここは変更しません。
# ========================================
item_effect_duration = 350
game_over_flash_duration = 180

item_effect_start_time = -item_effect_duration
item_effect_x = 0
item_effect_y = 0

game_over_effect_start_time = -game_over_flash_duration
game_over_flash = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
game_over_flash.fill((255, 50, 50, 100))

# 文字の画像は、内容が変わるときだけ作り直します。
score_text = font.render("Score: 0", True, text_color)
item_effect_text = font.render("+100", True, item_color)
game_over_text = game_over_font.render("GAME OVER", True, enemy_color)
restart_text = font.render("Press R to Restart", True, text_color)

game_over_x = screen_width // 2 - game_over_text.get_width() // 2
game_over_y = screen_height // 2 - game_over_text.get_height()
restart_x = screen_width // 2 - restart_text.get_width() // 2
restart_y = screen_height // 2 + 20

# game.pyがある場所を基準にして、assetsフォルダを探します。
game_folder = os.path.dirname(os.path.abspath(__file__))
local_asset_folder = os.path.join(game_folder, "assets")

if os.path.exists(local_asset_folder):
    asset_folder = local_asset_folder
else:
    asset_folder = os.path.abspath(os.path.join(game_folder, "..", "..", "assets"))

image_folder = os.path.join(asset_folder, "images")
sound_folder = os.path.join(asset_folder, "sounds")

player_image_path = os.path.join(image_folder, "player.png")
enemy_image_path = os.path.join(image_folder, "enemy.png")
item_image_path = os.path.join(image_folder, "item.png")
background_image_path = os.path.join(image_folder, "background.png")

player_image = None
enemy_image = None
item_image = None
background_image = None

# 画像があるときは画像を使い、ないときは色のついた図形を使います。
if os.path.exists(player_image_path):
    try:
        player_image = pygame.image.load(player_image_path).convert_alpha()
        player_image = pygame.transform.scale(player_image, (player_size, player_size))
    except (pygame.error, OSError):
        player_image = None

if os.path.exists(enemy_image_path):
    try:
        enemy_image = pygame.image.load(enemy_image_path).convert_alpha()
        enemy_image = pygame.transform.scale(enemy_image, (enemy_size, enemy_size))
    except (pygame.error, OSError):
        enemy_image = None

if os.path.exists(item_image_path):
    try:
        item_image = pygame.image.load(item_image_path).convert_alpha()
        item_image = pygame.transform.scale(item_image, (item_size, item_size))
    except (pygame.error, OSError):
        item_image = None

if os.path.exists(background_image_path):
    try:
        background_image = pygame.image.load(background_image_path).convert()
        background_image = pygame.transform.scale(
            background_image, (screen_width, screen_height)
        )
    except (pygame.error, OSError):
        background_image = None

# 音を使えないパソコンでは、無音のままゲームを続けます。
sound_ready = True
if pygame.mixer.get_init() is None:
    try:
        pygame.mixer.init()
    except pygame.error:
        sound_ready = False

item_get_sound = None
game_over_sound = None

item_get_sound_path = os.path.join(sound_folder, "item_get.wav")
game_over_sound_path = os.path.join(sound_folder, "game_over.wav")

if sound_ready and os.path.exists(item_get_sound_path):
    try:
        item_get_sound = pygame.mixer.Sound(item_get_sound_path)
    except (pygame.error, OSError):
        item_get_sound = None

if sound_ready and os.path.exists(game_over_sound_path):
    try:
        game_over_sound = pygame.mixer.Sound(game_over_sound_path)
    except (pygame.error, OSError):
        game_over_sound = None

# ========================================
# [READ] ゲーム開始時の状態
# 読んで確認します。変更しません。
# ========================================
# ゲームを始めるときの位置とスコアです。
player_x = screen_width // 2 - player_size // 2
player_y = screen_height - player_size - 30

enemy1_x = random.randint(0, screen_width - enemy_size)
enemy1_y = 50

enemy2_x = random.randint(0, screen_width - enemy_size)
enemy2_y = -150

enemy3_x = random.randint(0, screen_width - enemy_size)
enemy3_y = -350

item_x = random.randint(0, screen_width - item_size)
item_y = random.randint(60, screen_height - item_size)

score = 0
game_over = False
running = True

# ゲームを動かすための処理
# ========================================
# [SYSTEM] イベント処理とゲームループ
# ここは変更しません。
# ========================================
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False

            # Game OverのときにRキーを押すと、最初から始めます。
            if event.key == pygame.K_r and game_over:
                player_x = screen_width // 2 - player_size // 2
                player_y = screen_height - player_size - 30

                enemy1_x = random.randint(0, screen_width - enemy_size)
                enemy1_y = 50

                enemy2_x = random.randint(0, screen_width - enemy_size)
                enemy2_y = -150

                enemy3_x = random.randint(0, screen_width - enemy_size)
                enemy3_y = -350

                item_x = random.randint(0, screen_width - item_size)
                item_y = random.randint(60, screen_height - item_size)

                score = 0
                game_over = False
                item_effect_start_time = -item_effect_duration
                game_over_effect_start_time = -game_over_flash_duration

                # スコア表示の準備
                score_text = font.render("Score: 0", True, text_color)

    if not game_over:
        # ========================================
        # [READ] 押されているキーを調べる
        # 読んで確認します。変更しません。
        # ========================================
        keys = pygame.key.get_pressed()

        # キーを押している間、プレイヤーの座標を変えます。
        # ========================================
        # [LEARNED] プレイヤーを動かす
        # ========================================
        if keys[pygame.K_RIGHT]:
            player_x = player_x + player_speed

        if keys[pygame.K_LEFT]:
            player_x = player_x - player_speed

        if keys[pygame.K_DOWN]:
            player_y = player_y + player_speed

        if keys[pygame.K_UP]:
            player_y = player_y - player_speed

        # プレイヤーが画面の外へ出ないようにします。
        # ========================================
        # [LEARNED] 画面の外へ出ない
        # ========================================
        if player_x < 0:
            player_x = 0

        if player_x > screen_width - player_size:
            player_x = screen_width - player_size

        if player_y < 0:
            player_y = 0

        if player_y > screen_height - player_size:
            player_y = screen_height - player_size

        # 3体の敵を、それぞれ下へ動かします。
        # ========================================
        # [LEARNED] 3体の敵を動かす
        # ========================================
        enemy1_y = enemy1_y + enemy_speed
        enemy2_y = enemy2_y + enemy_speed
        enemy3_y = enemy3_y + enemy_speed

        # 敵が画面の下へ出たら、上へ戻してx座標を変えます。
        if enemy1_y > screen_height:
            enemy1_y = -enemy_size
            enemy1_x = random.randint(0, screen_width - enemy_size)

        if enemy2_y > screen_height:
            enemy2_y = -enemy_size
            enemy2_x = random.randint(0, screen_width - enemy_size)

        if enemy3_y > screen_height:
            enemy3_y = -enemy_size
            enemy3_x = random.randint(0, screen_width - enemy_size)

        # ゲームを動かすための処理
        # ========================================
        # [READ] 当たり判定に使う四角
        # 読んで確認します。変更しません。
        # ========================================
        player_rect = pygame.Rect(player_x, player_y, player_size, player_size)
        enemy1_rect = pygame.Rect(enemy1_x, enemy1_y, enemy_size, enemy_size)
        enemy2_rect = pygame.Rect(enemy2_x, enemy2_y, enemy_size, enemy_size)
        enemy3_rect = pygame.Rect(enemy3_x, enemy3_y, enemy_size, enemy_size)
        item_rect = pygame.Rect(item_x, item_y, item_size, item_size)

        # プレイヤーと3体の敵がぶつかったかを、それぞれ調べます。
        # ========================================
        # [LEARNED] 3体の敵との当たり判定
        # ========================================
        if player_rect.colliderect(enemy1_rect):
            game_over = True

        if not game_over and player_rect.colliderect(enemy2_rect):
            game_over = True

        if not game_over and player_rect.colliderect(enemy3_rect):
            game_over = True

        # Game Over時の演出と効果音
        if game_over:
            game_over_effect_start_time = pygame.time.get_ticks()

            if game_over_sound is not None:
                try:
                    game_over_sound.play()
                except pygame.error:
                    game_over_sound = None

        # プレイヤーがアイテムを取ったら、50〜150点を選びます。
        # ========================================
        # [LEARNED] アイテム取得・スコア・再配置
        # ========================================
        if not game_over and player_rect.colliderect(item_rect):
            # [READ] 改造例：ランダム得点
            item_points = random.randint(50, 150)
            score = score + item_points
            # [SYSTEM] 表示する+得点も、実際の増加量に合わせます。
            item_effect_text = font.render("+" + str(item_points), True, item_color)

            # スコア表示の準備
            score_text = font.render("Score: " + str(score), True, text_color)

            # アイテム取得時の演出
            item_effect_x = item_x + item_size // 2
            item_effect_y = item_y
            item_effect_start_time = pygame.time.get_ticks()

            item_x = random.randint(0, screen_width - item_size)
            item_y = random.randint(60, screen_height - item_size)

            if item_get_sound is not None:
                try:
                    item_get_sound.play()
                except pygame.error:
                    item_get_sound = None

    # ゲームを動かすための処理
    # ========================================
    # [SYSTEM] 画面を描く
    # ここは変更しません。
    # ========================================
    if background_image is not None:
        screen.blit(background_image, (0, 0))
    else:
        screen.fill(background_color)

    if item_image is not None:
        screen.blit(item_image, (item_x, item_y))
    else:
        pygame.draw.rect(screen, item_color, (item_x, item_y, item_size, item_size))

    if enemy_image is not None:
        screen.blit(enemy_image, (enemy1_x, enemy1_y))
        screen.blit(enemy_image, (enemy2_x, enemy2_y))
        screen.blit(enemy_image, (enemy3_x, enemy3_y))
    else:
        pygame.draw.rect(
            screen, enemy_color, (enemy1_x, enemy1_y, enemy_size, enemy_size)
        )
        pygame.draw.rect(
            screen, enemy_color, (enemy2_x, enemy2_y, enemy_size, enemy_size)
        )
        pygame.draw.rect(
            screen, enemy_color, (enemy3_x, enemy3_y, enemy_size, enemy_size)
        )

    if player_image is not None:
        screen.blit(player_image, (player_x, player_y))
    else:
        pygame.draw.rect(
            screen, player_color, (player_x, player_y, player_size, player_size)
        )

    screen.blit(score_text, (20, 20))

    # ゲームの演出
    # ========================================
    # [SYSTEM] 効果音と画面エフェクト
    # ここは変更しません。
    # ========================================
    current_time = pygame.time.get_ticks()

    if current_time - item_effect_start_time < item_effect_duration:
        item_effect_text_x = item_effect_x - item_effect_text.get_width() // 2
        item_effect_text_y = item_effect_y - item_effect_text.get_height()
        screen.blit(item_effect_text, (item_effect_text_x, item_effect_text_y))

    if current_time - game_over_effect_start_time < game_over_flash_duration:
        screen.blit(game_over_flash, (0, 0))

    if game_over:
        screen.blit(game_over_text, (game_over_x, game_over_y))
        screen.blit(restart_text, (restart_x, restart_y))

    # ========================================
    # [SYSTEM] 画面更新と60FPS制御
    # ここは変更しません。
    # ========================================
    pygame.display.flip()
    clock.tick_busy_loop(fps)

# ========================================
# [SYSTEM] ゲームを終了する
# ========================================
pygame.quit()
# ========================================
