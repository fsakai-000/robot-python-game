"""[SYSTEM] この改造例だけの描画。hp・score・座標は変更しない。"""


from pathlib import Path


import pygame


def load_sprite(folder, name, size):
    try:
        image = pygame.image.load(str(Path(folder) / "images" / name)).convert_alpha()
        return pygame.transform.scale(image, (size, size))
    except (OSError, pygame.error):
        return None


def draw_health(screen, image, x, y, size):
    if image is None:
        pygame.draw.rect(screen, (86, 227, 177), (x, y, size, size))
        pygame.draw.line(screen, (10, 48, 49), (x + size // 2, y + 10), (x + size // 2, y + size - 10), 5)
        pygame.draw.line(screen, (10, 48, 49), (x + 10, y + size // 2), (x + size - 10, y + size // 2), 5)
    else:
        screen.blit(image, (x, y))
